This folder contains notes, assignment for the Data Visualization with Python class.

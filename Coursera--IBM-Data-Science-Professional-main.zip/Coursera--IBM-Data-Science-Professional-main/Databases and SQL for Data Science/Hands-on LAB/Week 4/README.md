This week covers assignments on "Working with real-world data sets and built-in SQl functions

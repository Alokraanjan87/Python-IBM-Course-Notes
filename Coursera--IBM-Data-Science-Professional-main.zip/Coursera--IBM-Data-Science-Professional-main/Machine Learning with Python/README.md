This `repo` contains course notes, labs, and assignment for the Machine Learning with Python class.
In the `Lab: Simple Linear Regression`, the scikit-learn library is used to implement Simple Linear Regression

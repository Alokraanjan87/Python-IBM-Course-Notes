This folder contains labs, assignment for the Data Analysis with Python class.

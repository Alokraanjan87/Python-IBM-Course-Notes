This `README` contains lab notes for the `Python for Data Science and AI` class.

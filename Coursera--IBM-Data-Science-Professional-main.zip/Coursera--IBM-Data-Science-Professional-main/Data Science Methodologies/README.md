This `README` contains lesson notes for this class

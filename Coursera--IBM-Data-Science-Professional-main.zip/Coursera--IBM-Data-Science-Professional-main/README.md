# Coursera--IBM-Data-Science-Professional
This `repo` contains course notes, assignments and solved solution exercises in the "IBM Data Science Professional Certificate" offered on Coursera by IBM. 
The specialization includes the following courses:
- What is Data Science?
- Tools for Data Science
- Data Science Methodology
- Python for Data Science and AI
- Databases and SQL for Data Science
- Data Analysis with Python
- Data Visualization with Python
- Machine Learning with Python
- Applied Data Science Capstone

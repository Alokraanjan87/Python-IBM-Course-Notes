This `README` contains materials for the `Tools for Data Science` class.

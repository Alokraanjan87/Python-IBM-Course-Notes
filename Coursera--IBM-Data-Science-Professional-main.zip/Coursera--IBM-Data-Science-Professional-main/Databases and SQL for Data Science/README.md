This course contains Hands-On Lab for the Databases and SQL for Data Science class.
